import os
import time
import copy
import argparse
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

from matplotlib import cm
from matplotlib.ticker import LinearLocator

from torchvision.utils import save_image
from utils import get_loops, get_dataset, get_network, get_eval_pool, evaluate_synset, get_daparam, match_loss, get_time, TensorDataset, epoch, DiffAugment, ParamDiffAug

import wandb
os.environ["WANDB_SILENT"] = "true"
#os.environ['WANDB_MODE'] = 'offline'






data_image  =  torch.load(os.path.join('result/creation', 'differ_none_CIFAR100_ConvNet_10ipc_1000it.pt'))
image = data_image['data']
print(image.shape)

differ_vis_unbias = torch.sum(image, dim = 0, keepdim = False)
differ_syn = differ_vis_unbias.detach().cpu().numpy()

z_sum = np.sum(differ_syn)
differ_syn_normalized = differ_syn/z_sum 

xsize = 32



"""dens = np.zeros(23)
for i in range(32):
    for j in range(32):
        distance_of_point = np.sqrt((i-xsize/2+0.5)**2 + (j-xsize/2+0.5)**2) 
            
        grid = int(distance_of_point)
        rate1 = distance_of_point - grid
        rate2 = 1 -rate1
        dens[grid] = dens[grid] +rate2
        dens[grid+1] = dens[grid+1] +rate1

print("dens",dens)


dens1 = np.zeros(150+2)
for i in range(150*2):
    for j in range(150*2):
        distance_of_point = np.sqrt((i-150+0.5)**2 + (j-150+0.5)**2) 
        grid = int(distance_of_point)
        if grid <= 150:
            rate1 = distance_of_point - grid
            rate2 = 1 -rate1
            dens1[grid] = dens1[grid] +1
            dens1[grid+1] = dens1[grid+1]

print("dens1",dens1)"""




"""def get_distribution(xsize, offset_range_nia2,radius_min,radius_range,thickness_min,thickness_range):
    
    length = int(xsize*0.5*1.414) + 1
    distribution = np.zeros(length)

    
    for i in range(offset_range_nia2):
        multiple = dens1[i]

        for j in range(radius_range):
            randradius_inside = radius_min + j 
            
            for q in range(thickness_range):
                randradius_outside = radius_min + j + thickness_min + q 

                coverarea = get_coverarea(xsize,length,randradius_inside, randradius_outside, i)
                #print("randradius_inside, randradius_outside, i",randradius_inside, randradius_outside, i ,coverarea)
                distribution = distribution + multiple * coverarea 
      
    return distribution"""




def get_coverarea(xsize,randradius_inside, randradius_outside, Cutring_centre_i, Cutring_centre_j):
    mesh= np.zeros((xsize,xsize))

    for i in range(xsize):
        for j in range(xsize):
            Distance_to_cutring_centre = np.sqrt((Cutring_centre_i - (i - xsize/2 + 0.5))**2 + (Cutring_centre_j - (j - xsize/2 + 0.5))**2)
            if (Distance_to_cutring_centre <= randradius_outside) and (Distance_to_cutring_centre >= randradius_inside):
                
                mesh[i,j] = 1
              
                       
    return mesh




def creation_mesh(xsize, offset_range_nia2,radius_min,radius_range,thickness_min,thickness_range):
    
    mesh= np.zeros((xsize,xsize))
    mesh_final= np.zeros((xsize,xsize))

    for i in range(offset_range_nia2):
        for j in range(offset_range_nia2):
            cutring_centre_to_pic_centre = np.sqrt(i**2 + j**2)
            if cutring_centre_to_pic_centre <= xsize/2:
                
                for p in range(radius_range):
                    randradius_inside = radius_min + p
        
                    for q in range(thickness_range):
                        randradius_outside = radius_min + p + thickness_min + q 

                        coverarea = get_coverarea(xsize,randradius_inside, randradius_outside,i,j)
                        #print("randradius_inside, randradius_outside, i",randradius_inside, randradius_outside, i ,coverarea)
                        mesh = mesh +  coverarea 

                


    for i in range(xsize):
        for j in range(xsize):
            
            mesh_final[i,j] = mesh[i, j] + mesh[xsize-i-1, xsize-j-1] + mesh[xsize-i-1, j] + mesh[i, xsize-j-1] 
    
    return mesh_final



    


def get_KI(xsize, offset_range_nia2,radius_min,radius_range,thickness_min,thickness_range):


    wandb.init(project= "correlation_KL_CIFAR100_11")
    wandb.config.offset_range_nia2 = offset_range_nia2
    wandb.config.radius_min = radius_min
    wandb.config.radius_range = radius_range
    wandb.config.thickness_min = thickness_min
    wandb.config.thickness_range = thickness_range


    Dis_Mesh = creation_mesh(xsize, offset_range_nia2,radius_min,radius_range,thickness_min,thickness_range)
    
    z_sum = np.sum(Dis_Mesh)
    z_max = np.max(Dis_Mesh)
    z_min = np.min(Dis_Mesh)

    Normalized_Dis_Mesh = Dis_Mesh/z_sum 


    
    KL_Divergence1 = np.sum(Normalized_Dis_Mesh*np.log(Normalized_Dis_Mesh/differ_syn_normalized))
    print("KL_Divergence1",KL_Divergence1)

    KL_Divergence2 = np.sum(differ_syn_normalized*np.log(differ_syn_normalized/Normalized_Dis_Mesh))
    print("KL_Divergence2",KL_Divergence2)

    MEAN_Firstorder = np.sum(np.abs(differ_syn_normalized-Normalized_Dis_Mesh))
    print("MEAN_Firstorder",MEAN_Firstorder)

    MEAN_Secondorder = np.sum((differ_syn_normalized-Normalized_Dis_Mesh)**2)
    print("MEAN_Secondorder",MEAN_Secondorder)


    mesh_sum = z_sum
    print("mesh_sum",mesh_sum)

    mesh_max = z_max
    print("mesh_max",mesh_max)

    mesh_min = z_min
    print("mesh_min",mesh_min)

    
    print("Dis_Mesh",Dis_Mesh)



    wandb.log({'KL_Divergence1': KL_Divergence1})
    wandb.log({'KL_Divergence2': KL_Divergence2})
    wandb.log({'MEAN_Firstorder': MEAN_Firstorder})
    wandb.log({'MEAN_Secondorder': MEAN_Secondorder})
    wandb.log({'Mesh_sum': mesh_sum})
    wandb.log({'Mesh_max': mesh_max})
    wandb.finish()
    
    return









Test_list = {
    'offset_range': [10,20,30,40,50,60,70,80,90,100], # degree_min 'none','color','crop','cutout','flip','scale','rotate' 
    'nia4_radius_min': [10,20,30], # degree_range 'none','color','crop','cutout','flip','scale','rotate'
    'nia4_radius_range': [5,10], #'none','color','crop','cutout','flip','scale','rotate','new','new1','new2'
    'thickness_min': [5,10], #'none','color','crop','cutout','flip','scale','rotate'
    'thickness_range': [5,10], #'none','color','crop','cutout','flip','scale','rotate','new','new1','new2'
}
   

if __name__ == '__main__':
    for para_0 in Test_list['offset_range']:
        for para_1 in Test_list['nia4_radius_min']:
            for para_2 in Test_list['nia4_radius_range']:
                for para_3 in Test_list['thickness_min']:
                    for para_4 in Test_list['thickness_range']:
                        get_KI(xsize, para_0,para_1,para_2,para_3,para_4)