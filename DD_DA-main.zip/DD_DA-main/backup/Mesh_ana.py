import os
import time
import copy
import argparse
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

from matplotlib import cm
from matplotlib.ticker import LinearLocator

from torchvision.utils import save_image
from utils import get_loops, get_dataset, get_network, get_eval_pool, evaluate_synset, get_daparam, match_loss, get_time, TensorDataset, epoch, DiffAugment, ParamDiffAug




data_image  =  torch.load(os.path.join('result/creation', 'differ_none_CIFAR100_ConvNet_10ipc_800it.pt'))
image = data_image['data']
print(image.shape)

differ_vis_unbias = torch.sum(image, dim = 0, keepdim = False)
differ_syn = differ_vis_unbias.detach().cpu().numpy()

z_sum = np.sum(differ_syn)
differ_syn_normalized = differ_syn/z_sum *100



offset_range_nia2 = 10
radius_min = 30
radius_range = 10
thickness_min = 5
thickness_range = 5
xsize = 32

dens = np.zeros(23)
for i in range(32):
    for j in range(32):
        distance_of_point = np.sqrt((i-xsize/2+0.5)**2 + (j-xsize/2+0.5)**2) 
            
        grid = int(distance_of_point)
        rate1 = distance_of_point - grid
        rate2 = 1 -rate1
        dens[grid] = dens[grid] +rate2
        dens[grid+1] = dens[grid+1] +rate1

print("dens",dens)


dens1 = np.zeros(offset_range_nia2+2)
for i in range(offset_range_nia2*2):
    for j in range(offset_range_nia2*2):
        distance_of_point = np.sqrt((i-offset_range_nia2+0.5)**2 + (j-offset_range_nia2+0.5)**2) 
        grid = int(distance_of_point)
        if grid <= offset_range_nia2:
            rate1 = distance_of_point - grid
            rate2 = 1 -rate1
            dens1[grid] = dens1[grid] +1
            dens1[grid+1] = dens1[grid+1]

print("dens1",dens1)




def get_distribution(xsize, offset_range_nia2,radius_min,radius_range,thickness_min,thickness_range):
    
    length = int(xsize*0.5*1.414) + 1
    distribution = np.zeros(length)

    
    for i in range(offset_range_nia2):
        multiple = dens1[i]
        print("i",i)

        for j in range(radius_range):
            randradius_inside = radius_min + j 
            
            for q in range(thickness_range):
                randradius_outside = radius_min + j + thickness_min + q 

                coverarea = get_coverarea(xsize,length,randradius_inside, randradius_outside, i)
                #print("randradius_inside, randradius_outside, i",randradius_inside, randradius_outside, i ,coverarea)
                distribution = distribution + multiple * coverarea 
      
    return distribution




def get_coverarea(xsize,length,randradius_inside, randradius_outside, Cutring_centre):
    density = np.zeros(length)
    for i in range(xsize):
        for j in range(xsize):
            Distance_to_cutring_centre = np.sqrt((Cutring_centre - (i - xsize/2 + 0.5))**2 + (j - xsize/2 + 0.5)**2)
            if (Distance_to_cutring_centre <= randradius_outside) and (Distance_to_cutring_centre >= randradius_inside):
                
                distance_of_point = np.sqrt((i-xsize/2+0.5)**2 + (j-xsize/2+0.5)**2) 
                if distance_of_point < length:
                    grid_distance_of_point = int(distance_of_point)
                    #if grid_distance_of_point <= 5:
                        #print("grid_distance_of_point", grid_distance_of_point, i ,j )
                    rate1 = distance_of_point - grid_distance_of_point
                    rate2 = 1 -rate1
                    density[grid_distance_of_point] = density[grid_distance_of_point] + (rate2/dens[grid_distance_of_point])
                    density[grid_distance_of_point+1] = density[grid_distance_of_point+1] + (rate1/dens[grid_distance_of_point+1])
                 
                       
    return density



#Param_analyze = Parameters_analyze(xsize, offset_range_nia2,radius_min,radius_range,thickness_min,thickness_range)
Distribution_analyze = get_distribution(xsize, offset_range_nia2,radius_min,radius_range,thickness_min,thickness_range)
print("Distribution_analyze",Distribution_analyze)


def creation_mesh(xsize,Distribution_analyze):
    mesh= np.zeros((xsize,xsize))

    for i in range(xsize):
        for j in range(xsize):
            distance = np.sqrt((i-xsize/2+0.5)**2 + (j-xsize/2+0.5)**2)
            grid_num = int(distance)
            if grid_num >= 22: 
                print("i,j",i,j,distance)
            rate1 = distance -  grid_num
            rate2 = 1 -rate1 
            density = rate1*Distribution_analyze[grid_num+1] + rate2*Distribution_analyze[grid_num]
            mesh[i,j] = density

    
    return mesh

    
Dis_Mesh = creation_mesh(xsize,Distribution_analyze)
z_sum = np.sum(Dis_Mesh)
if z_sum == 0:
    z_sum = 1

Normalized_Dis_Mesh = Dis_Mesh/z_sum*100




KI_Divergence = np.sum(differ_syn_normalized*np.log(differ_syn_normalized/Normalized_Dis_Mesh))
print("KI_Divergence",KI_Divergence)

KI_Divergence1 = np.sum(Normalized_Dis_Mesh*np.log(Normalized_Dis_Mesh/differ_syn_normalized))
print("KI_Divergence1",KI_Divergence1)

MEAN_Divergence = np.sum((differ_syn_normalized-Normalized_Dis_Mesh)**2)
print("MEAN_Divergence",MEAN_Divergence)


fig, ax = plt.subplots(subplot_kw={"projection": "3d"})

# Make data.
X = np.arange(0, 32)
Y = np.arange(0, 32)
X, Y = np.meshgrid(X, Y)

# Plot the surface.
surf = ax.plot_surface(X, Y, Normalized_Dis_Mesh[X,Y], cmap=cm.coolwarm,
                    linewidth=0, antialiased=False)

z_max = np.max(Normalized_Dis_Mesh)
z_min = np.min(Normalized_Dis_Mesh)
# Customize the z axis.
ax.set_zlim(z_min, z_max)
ax.zaxis.set_major_locator(LinearLocator(10))
# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()

       




