import torch
import torch.nn as nn
import numpy as np


a= np.array([

        [[[1.0, 2.0],
          [3.0, 4.0]],

         [[10.0, 20.0],
          [30.0, 40.0]],

         [[100.0, 200.0],
          [300.0, 400.0]]],

        [[[10.0, 20.0],
          [30.0, 40.0]],

         [[100.0, 200.0],
          [300.0, 400.0]],

         [[1000.0, 2000.0],
          [3000.0, 4000.0]]]
          
          ])

rand = torch.from_numpy(a)

print('rand',rand)
print('shape',rand.shape)


rand_mean_1 = rand.mean(dim=1, keepdim=True)
rand_mean_2 = rand.mean(dim=[1, 2, 3], keepdim=True)

print('rand_mean_1',rand_mean_1)
print('rand_mean_2',rand_mean_2)