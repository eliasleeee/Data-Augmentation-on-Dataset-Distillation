import os
import time
import copy
import argparse
import numpy as np
import torch
import torch.nn as nn
from torchvision import datasets, transforms
import torchvision
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator
from torchvision.utils import save_image
from utils import get_loops, get_dataset, get_network, get_eval_pool, evaluate_synset, get_daparam, match_loss, get_time, TensorDataset, epoch, DiffAugment, ParamDiffAug




def main():

        parser = argparse.ArgumentParser(description='Parameter Processing')
        parser.add_argument('--method', type=str, default='DSA', help='DC/DSA')
        parser.add_argument('--stage', type=str, default='two', help='one stage/two stage')
        parser.add_argument('--evaluate_synthetic_data', type=str, default='True', help='True/False')
        parser.add_argument('--create_synthetic_data', type=str, default='True', help='True/False')
        parser.add_argument('--data_path_of_synthetic_data', type=str, default='data', help='dataset path for getting synthetic data')
        parser.add_argument('--seedsetting', type=str, default=3, help='seed = ?')
        parser.add_argument('--dataset', type=str, default='CIFAR10', help='dataset')
        parser.add_argument('--model', type=str, default='ConvNet', help='model')
        parser.add_argument('--ipc', type=int, default=10 , help='image(s) per class')
        parser.add_argument('--eval_mode', type=str, default='S', help='eval_mode') # S: the same to training model, M: multi architectures,  W: net width, D: net depth, A: activation function, P: pooling layer, N: normalization layer,
        parser.add_argument('--num_eval', type=int, default=5, help='the number of evaluating randomly initialized models')
        parser.add_argument('--epoch_eval_train', type=int, default=300, help='epochs to train a model with synthetic data')
        parser.add_argument('--normalize_data', action="store_true", default=True, help='the number of evaluating randomly initialized models')
        parser.add_argument('--Iteration', type=int, default=1000, help='training iterations')
        parser.add_argument('--lr_img', type=float, default=0.1, help='learning rate for updating synthetic images')
        parser.add_argument('--lr_net', type=float, default=0.01, help='learning rate for updating network parameters')
        parser.add_argument('--batch_real', type=int, default=512, help='batch size for real data')
        parser.add_argument('--batch_train', type=int, default=512, help='batch size for training networks')
        parser.add_argument('--init', type=str, default='real', help='noise/real: initialize synthetic images from random noise or randomly sampled real images.')
        parser.add_argument('--dsa_strategy_stage_1', type=str, default='none', help='differentiable Siamese augmentation strategy, full = color_crop_cutout_flip_scale_rotate')
        parser.add_argument('--dsa_strategy_stage_2', type=str, default='autoaug', help='differentiable Siamese augmentation strategy, full = color_crop_cutout_flip_scale_rotate')
        parser.add_argument('--data_path', type=str, default='DD_DA/result/RepeatExp/fake/CIFAR10', help='dataset path')
        parser.add_argument('--save_path', type=str, default='DD_DA/DAtest', help='path to save results')
        parser.add_argument('--dis_metric', type=str, default='ours', help='distance metric')

        args = parser.parse_args() 
        args.outer_loop, args.inner_loop = get_loops(args.ipc) 
        args.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        args.dsa_param_stage_1 = ParamDiffAug()
        args.dsa_param_stage_2 = ParamDiffAug()
        args.dsa = True if args.method == 'DSA' else False 
        args.twostage = True if args.stage == 'two' else False
        args.evaluate_sd = True if args.evaluate_synthetic_data == 'True' else False
        args.create_sd = True if args.create_synthetic_data == 'True' else False
        
        
        

        channel = 3
        im_size = (32, 32)
        num_classes = 10
        mean = [0.4914, 0.4822, 0.4465]
        std = [0.2023, 0.1994, 0.2010]


        args.dsa_param_stage_2.rotate_degree = 15

        args.dsa_param_stage_2.ring_circlecutout = 1
        args.dsa_param_stage_2.radius_circlecutout = 5
        args.dsa_param_stage_2.thickness_circlecutout = 5
        args.dsa_param_stage_2.margin_circlecutout = 1
        args.dsa_param_stage_2.mosaicsize_circlecutout = 2
        
        args.dsa_param_stage_2.offset_range_nia2 = 40
        args.dsa_param_stage_2.radius_min = 20
        args.dsa_param_stage_2.radius_range = 10
        args.dsa_param_stage_2.thickness_min = 10
        args.dsa_param_stage_2.thickness_range = 5

        

        args.dsa_param_stage_2.offset_range = 5 
        args.dsa_param_stage_2.degree_min = 15
        args.dsa_param_stage_2.degree_range = 30


        args.dsa_param_stage_2.nia4_offset_range = 0
        args.dsa_param_stage_2.nia4_width_range = 14
        args.dsa_param_stage_2.nia4_width_min = 0


        args.aug = args.dsa_strategy_stage_2
        args.dsa_param_stage_2.normalize_data = args.normalize_data
        args.dsa_param_stage_2.dataset = args.dataset
        args.dsa_param_stage_2.aug = args.aug


        
  
    
   

    


        data_image  =  torch.load(os.path.join(args.data_path, 'image_syn_TWO_strategy_stage_0=none_CIFAR10_ConvNet_10ipc_Seed=1.pt'))
        image = data_image['data']

        save_name = os.path.join(args.save_path, 'test1.png')
        save_image(image, save_name, nrow=args.ipc) # Trying normalize = True/False or 0-1 ?may get better visual effects.
        




        # image_show = torch.zeros(1, image.size(1), image.size(2), image.size(3), dtype=image.dtype, device=image.device)
        image_show = image
        image_show_DA = DiffAugment(image_show, args.dsa_strategy_stage_2, seed=100000, param=args.dsa_param_stage_2)
        
        """for i in range(1):
       
            image_show_DA = DiffAugment(image_show_DA, args.dsa_strategy_stage_2, seed=i*10+1, param=args.dsa_param_stage_2)
            if i%100 == 0:
                print(i)
                differ_vis_unbias = torch.sum(torch.sum(image_show_DA, dim = 0, keepdim = False), dim = 0, keepdim = False)
                print(differ_vis_unbias)
        
        image_show_DA1 = DiffAugment(image_show, args.dsa_strategy_stage_2, seed=1, param=args.dsa_param_stage_2)


        
        differ_vis_unbias = torch.sum(torch.sum(image_show_DA, dim = 0, keepdim = False), dim = 0, keepdim = False)
        plt.imshow(differ_vis_unbias, cmap='hot', interpolation='nearest')
        plt.colorbar()
        plt.show()
        

        fig, ax = plt.subplots(subplot_kw={"projection": "3d"})

        # Make data.
        X = np.arange(0, 32)
        Y = np.arange(0, 32)
        X, Y = np.meshgrid(X, Y)

    

        # Plot the surface.
        surf = ax.plot_surface(X, Y, differ_vis_unbias[X,Y], cmap=cm.coolwarm,
                            linewidth=0, antialiased=False)

        # Customize the z axis.

        z_max = torch.max(differ_vis_unbias)
        z_min = torch.min(differ_vis_unbias)
        # Customize the z axis.
        ax.set_zlim(z_min, z_max)

        ax.zaxis.set_major_locator(LinearLocator(10))
        # A StrMethodFormatter is used automatically
        ax.zaxis.set_major_formatter('{x:.02f}')

        # Add a color bar which maps values to colors.
        fig.colorbar(surf, shrink=0.5, aspect=5)

        plt.show()"""

        torch.save({'data': copy.deepcopy(image_show_DA.detach().cpu())}, os.path.join(args.save_path, 'show.png'))
        
        ''' visualize and save '''
        it = 0
        save_name = os.path.join(args.save_path, 'test.png')
        image_show_DA_vis = copy.deepcopy(image_show_DA.detach().cpu())
        for ch in range(channel):
            image_show_DA_vis[:, ch] = image_show_DA_vis[:, ch]  * std[ch] + mean[ch]
        image_show_DA_vis[image_show_DA_vis<0] = 0.0
        image_show_DA_vis[image_show_DA_vis>1] = 1.0
        save_image(image_show_DA_vis[0], save_name, nrow=args.ipc) # Trying normalize = True/False or 0-1 ?may get better visual effects.
        
        #print('size',image_show.shape)
        #print('image_show',image_show)
        #print('image_show_DA',image_show_DA)
        #print('image_show_DA_vis',image_show_DA_vis)


        """ it = 0
        save_name = os.path.join(args.save_path, 'test1.png')
        image_show_DA_vis1 = copy.deepcopy(image_show_DA1.detach().cpu())
        for ch in range(channel):
            image_show_DA_vis1[:, ch] = image_show_DA_vis1[:, ch]  * std[ch] + mean[ch]
        image_show_DA_vis1[image_show_DA_vis1<0] = 0.0
        image_show_DA_vis1[image_show_DA_vis1>1] = 1.0
        save_image(image_show_DA_vis1[0], save_name, nrow=args.ipc) # Trying normalize = True/False or 0-1 ?may get better visual effects.
        
        print('size',image_show.shape)
        print('image_show',image_show)
        print('image_show_DA',image_show_DA1)
        print('image_show_DA_vis',image_show_DA_vis1)"""


if __name__ == '__main__':
    main()       




